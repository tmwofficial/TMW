// Import Firebase modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";
import { 
  getFirestore, 
  doc, 
  getDoc, 
  updateDoc, 
  setDoc 
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-storage.js";

// Your Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBXXQXDQsF9QYbsaLBNLc4cxH-6LEzjNs",
  authDomain: "translated-movie-world.firebaseapp.com",
  projectId: "translated-movie-world",
  storageBucket: "translated-movie-world.firebasestorage.app",
  messagingSenderId: "20980905671",
  appId: "1:20980905671:web:6ae7e68335f847f37df0e2"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize services
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

// Helper functions
export async function addView(contentId){
  const docRef = doc(db, "contents", contentId);
  const docSnap = await getDoc(docRef);
  if(docSnap.exists()){
    await updateDoc(docRef, { views: (docSnap.data().views || 0) + 1 });
  }
}

export async function followTalent(talentId, userId){
  const followerRef = doc(db, "talents", talentId, "followers", userId);
  await setDoc(followerRef, { followedAt: new Date() });
  const talentRef = doc(db, "talents", talentId);
  const docSnap = await getDoc(talentRef);
  await updateDoc(talentRef, { followers: (docSnap.data().followers || 0) + 1 });
}

export async function likeContent(contentId, userId){
  const likeRef = doc(db, "contents", contentId, "likes", userId);
  await setDoc(likeRef, { likedAt: new Date() });
  const contentRef = doc(db, "contents", contentId);
  const docSnap = await getDoc(contentRef);
  await updateDoc(contentRef, { likes: (docSnap.data().likes || 0) + 1 });
}

