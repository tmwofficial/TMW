import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";
import { auth } from "./firebase.js";

onAuthStateChanged(auth, (user)=>{
  if(!user){
    // Not logged in → redirect to admin login
    window.location.href = "admin_login.html";
  }
});