import { doc, getDoc, updateDoc, collection, getDocs, query, orderBy, limit } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore.js";
import { ref, getDownloadURL } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-storage.js";
import { db, storage } from "./firebase.js";

// --- TALENT DASHBOARD STATS ---
export async function loadTalentStats(talentId){
    const talentRef = doc(db, "talents", talentId);
    const talentSnap = await getDoc(talentRef);
    if(talentSnap.exists()){
        const data = talentSnap.data();
        document.getElementById("viewsCount").innerText = data.views || 0;
        document.getElementById("followersCount").innerText = data.followers || 0;
        document.getElementById("uploadsCount").innerText = data.uploads || 0;

        const profileImg = document.getElementById("profilePic");
        if(data.profilePic){
            getDownloadURL(ref(storage, data.profilePic))
            .then(url => profileImg.src = url);
        }
    }
}

// --- FEATURED TALENTS ---
export async function loadFeaturedTalents(){
    const q = query(collection(db, "talents"), orderBy("featured","desc"), limit(10));
    const talentList = document.getElementById("featuredTalents");
    talentList.innerHTML = "";
    const querySnapshot = await getDocs(q);
    querySnapshot.forEach((docSnap)=>{
        const data = docSnap.data();
        const card = document.createElement("div");
        card.classList.add("talent-card");
        card.innerHTML = `
            <img src="${data.profilePic || 'assets/images/avatar.png'}" alt="${data.name}">
            <div class="talent-name">${data.name}</div>
            <div class="talent-category">${data.category}</div>
            <button onclick="followTalent('${docSnap.id}')">${data.followed ? '✔ Following' : 'Follow'}</button>
        `;
        talentList.appendChild(card);
    });
}

// --- FOLLOW TALENT ---
export async function followTalent(talentId){
    const talentRef = doc(db, "talents", talentId);
    const talentSnap = await getDoc(talentRef);
    if(talentSnap.exists()){
        const data = talentSnap.data();
        await updateDoc(talentRef, { followers: (data.followers||0)+1, followed:true });
        loadFeaturedTalents();
    }
}

// --- LOAD TALENT CONTENT ---
export async function loadTalentContent(talentId, category){
    const contentRef = collection(db, "contents");
    const q = query(contentRef, orderBy("createdAt","desc"));
    const talentList = document.getElementById(category+"List");
    talentList.innerHTML = "";

    const querySnapshot = await getDocs(q);
    querySnapshot.forEach(docSnap=>{
        const data = docSnap.data();
        if(data.talentId === talentId && data.category === category){
            const card = document.createElement("div");
            card.classList.add("content-card");
            card.innerHTML = `
                <img src="${data.thumbnail || 'assets/images/content.png'}" alt="${data.title}">
                <div class="content-title">${data.title}</div>
                <div class="content-stats">
                    <span>Views: ${data.views||0}</span>
                    <span>Likes: ${data.likes||0}</span>
                </div>
                <button onclick="incrementView('${docSnap.id}')">Play/Stream</button>
                ${data.allowDownload ? `<a href="${data.fileUrl}" download>Download</a>` : ""}
            `;
            talentList.appendChild(card);
        }
    });
}

// --- INCREMENT VIEW ---
export async function incrementView(contentId){
    const contentRef = doc(db, "contents", contentId);
    const contentSnap = await getDoc(contentRef);
    if(contentSnap.exists()){
        const data = contentSnap.data();
        await updateDoc(contentRef, { views: (data.views||0)+1 });
        alert("Playing content...");
    }
}

// --- LIKE CONTENT ---
export async function likeContent(contentId){
    const contentRef = doc(db, "contents", contentId);
    const contentSnap = await getDoc(contentRef);
    if(contentSnap.exists()){
        const data = contentSnap.data();
        await updateDoc(contentRef, { likes: (data.likes||0)+1 });
    }
}